<?php
error_reporting(0);
session_start();

if(!isset($_SERVER['HTTP_REFERER'])) exit;
if(!isset($_SERVER['HTTP_HOST'])) exit;
if(!isset($_SESSION['USER_OK']));
if(!isset($_SESSION['SESSION_ID'])) exit;
if($_SESSION['USER_OK'] !== 'OK') exit;

$ref = $_SERVER['HTTP_REFERER'];
$host = $_SERVER['HTTP_HOST'];

if (strpos($ref, $host) !== FALSE) {
$include = 1;
include("inc/save.php");
}


?>