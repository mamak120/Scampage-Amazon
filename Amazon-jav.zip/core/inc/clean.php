<?php
session_start();

//Delete tmp dir 
if(isset($_SESSION['tmp_folder'])) {
	if(is_dir($_SESSION['tmp_folder']))
		recurse_delete($_SESSION['tmp_folder']);
}

?>