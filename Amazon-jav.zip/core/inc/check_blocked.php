<?php
error_reporting(0);
require_once 'functions.php';
require_once 'config.php';
include 'log.php';


$ip = get_client_ip();

function get_referrer()
{
	if(isset($_SESSION['REFERER']))
		return $_SESSION['REFERER'];

 	if(isset($_SERVER['HTTP_REFERER']))
 		return $_SERVER['HTTP_REFERER'];

 	return '';
}

function set_ip_session_info()
{
	global $ip;

	$ip_geo_info = getIpInfoLive($ip);
	$ip_isp = isset($ip_geo_info["isp"]) ? $ip_geo_info["isp"] : '';
	$ip_organization = isset($ip_geo_info["org"]) ? $ip_geo_info["org"] : '';
	$city = isset($ip_geo_info["city"]) ? $ip_geo_info["city"] : '';
	$region_name = isset($ip_geo_info["regionName"]) ? $ip_geo_info["regionName"] : '';
	$ip_country = isset($ip_geo_info["country"]) ? $ip_geo_info["country"] : '';
	$ip_country_code = isset($ip_geo_info["COUNTRY_CODE"]) ? $ip_geo_info["COUNTRY_CODE"] : '';
	$hostname = gethostbyaddr($ip);
	$referer = get_referrer();
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$browser_name = get_browser_name();
	$os_name = get_OS();

	$ip_info = array();
	$ip_info['IP'] = $ip;
	$ip_info['IP_ISP'] = $ip_isp;
	$ip_info['IP_ORGANIZATION'] = $ip_organization;
	$ip_info['IP_CITY'] = $city;
	$ip_info['IP_REGION'] = $region_name;
	$ip_info['IP_COUNTRY'] = $ip_country;
	$ip_info['COUNTRY_CODE'] = $ip_country_code;
	$ip_info['HOSTNAME'] = $hostname;
	$ip_info['REFERER'] = $referer;
	$ip_info['USERAGENT'] = $useragent;
	$ip_info['BROWSER'] = $browser_name;
	$ip_info['PLATFORM'] = $os_name;

	$_SESSION['IP_INFO'] = $ip_info;
}


function check_and_set_session_missing_ip_info()
{
	if(!isset($_SESSION['IP_INFO']['IP_COUNTRY']))
	{
		if(isset($_SESSION['IP_SCORE_INFO']['IP_COUNTRY']))
			$_SESSION['IP_INFO']['IP_COUNTRY'] = $_SESSION['IP_SCORE_INFO']['IP_COUNTRY'];
	}

	if(!isset($_SESSION['IP_INFO']['IP_ORGANIZATION']))
	{
		if(isset($_SESSION['IP_SCORE_INFO']['IP_ORGANIZATION']))
			$_SESSION['IP_INFO']['IP_ORGANIZATION'] = $_SESSION['IP_SCORE_INFO']['IP_ORGANIZATION'];
	}

	if(!isset($_SESSION['IP_INFO']['IP_CITY']))
	{
		if(isset($_SESSION['IP_SCORE_INFO']['IP_CITY']))
			$_SESSION['IP_INFO']['IP_CITY'] = $_SESSION['IP_SCORE_INFO']['IP_CITY'];
	}

	if(!isset($_SESSION['IP_INFO']['IP_ISP']))
	{
		if(isset($_SESSION['IP_SCORE_INFO']['IP_ISP']))
			$_SESSION['IP_INFO']['IP_ISP'] = $_SESSION['IP_SCORE_INFO']['IP_ISP'];
	}

	if(!isset($_SESSION['IP_INFO']['IP_REGION']))
	{
		if(isset($_SESSION['IP_SCORE_INFO']['IP_REGION']))
			$_SESSION['IP_INFO']['IP_REGION'] = $_SESSION['IP_SCORE_INFO']['IP_REGION'];
	}

	if(!isset($_SESSION['IP_INFO']['HOSTNAME']))
	{
		if(isset($_SESSION['IP_SCORE_INFO']['HOSTNAME']))
			$_SESSION['IP_INFO']['HOSTNAME'] = $_SESSION['IP_SCORE_INFO']['HOSTNAME'];
	}
}

function set_ip_score_info()
{
	global $ip;
	$ip_score_info = array();

	$ip_score_info = getIpScoreLive($ip);
	$ip_score_is_success = isset($ip_score_info["success"]) ? $ip_score_info["success"] : false;
	$ip_score_ip_isp = isset($ip_score_info["ISP"]) ? $ip_score_info["ISP"] : '';
	$ip_score_country_code = isset($ip_score_info["country_code"]) ? $ip_score_info["country_code"] : '';
	$ip_score_ip_organization = isset($ip_score_info["organization"]) ? $ip_score_info["organization"] : '';
	$ip_score_ip_city = isset($ip_score_info["city"]) ? $ip_score_info["city"] : '';
	$ip_score_ip_region = isset($ip_score_info["region"]) ? $ip_score_info["region"] : '';
	$ip_score_ip_hostname = isset($ip_score_info["host"]) ? $ip_score_info["host"] : '';
	$is_proxy = isset($ip_score_info["proxy"]) ? $ip_score_info["proxy"] : false;
	$is_tor = isset($ip_score_info["tor"]) ? $ip_score_info["tor"] : false;
	$is_vpn = isset($ip_score_info["vpn"]) ? $ip_score_info["vpn"] : false;
	$is_crawler = isset($ip_score_info["is_crawler"]) ? $ip_score_info["is_crawler"] : false;
	$fraud_score = isset($ip_score_info["fraud_score"]) ? $ip_score_info["fraud_score"] : 0;

	$ip_score_info['IS_IP_SCORE_SUCCESS'] = $ip_score_is_success;
	$_SESSION['IP_SCORE_INFO'] = $ip_score_info;

	if($ip_score_is_success === NULL || $ip_score_is_success == '' || !$ip_score_is_success) return;


	$ip_score_info['IP_COUNTRY'] = $ip_score_country_code;
	$ip_score_info['IP_ORGANIZATION'] = $ip_score_ip_organization;
	$ip_score_info['IP_CITY'] = $ip_score_ip_city;
	$ip_score_info['IP_ISP'] = $ip_score_ip_isp;
	$ip_score_info['IP_REGION'] = $ip_score_ip_region;
	$ip_score_info['HOSTNAME'] = $ip_score_ip_hostname;
	$ip_score_info['IS_PROXY'] = $is_proxy;
	$ip_score_info['IS_TOR'] = $is_tor;
	$ip_score_info['IS_VPN'] = $is_vpn;
	$ip_score_info['IS_CRAWLER'] = $is_crawler;
	$ip_score_info['FRAUD_SCORE'] = $fraud_score;

	$_SESSION['IP_SCORE_INFO'] = $ip_score_info;
}

set_ip_session_info();

if($enable_live_ip_score_check)
{
	set_ip_score_info();
	check_and_set_session_missing_ip_info();
}



if($enable_blocker)
{
	$is_blocked = false;

	if(!isValidIp($ip))
	{
		$is_blocked = true;
	}
	else if($enable_ref_protection)
	{
		if(!is_referer_allowed($_SESSION['IP_INFO']['REFERER']))
		{
			$is_blocked = true;
		}
	}
	else if(isBlocked($_SESSION['IP_INFO']))
	{
		$is_blocked = true;
	}
	else if($enable_live_ip_score_check)
	{
		if(!IsIpFraudFilterPass($_SESSION['IP_SCORE_INFO']))
		{
			$is_blocked = true;
		}
	}

	if($is_blocked)
	{
		if($log_visits)
		{
			log_blocked_visit();
		}
		
		$_SESSION['USER_OK'] = '-1';
		exit_404();
	}
	$_SESSION['USER_OK'] = 'OK';
}
else 
{
	$_SESSION['USER_OK'] = 'OK';
}

?>